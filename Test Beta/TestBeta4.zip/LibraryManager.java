// Declaration:
// Library Manager version: Test Beta 4
// Package Build: 18B072826UD-TB4
// Copyright (C) Dream Project Group
import java.util.Random;
import java.io.*;
import java.util.Scanner;
public class LibraryManager{
	final String signatureSkeleton = "TestBeta3" + "alpine.mldy" + "8" + "DreamOS";
	final String finalSignature = "CBED2FD52CED6D52973A92C7AC393C83B9272A8BCAB0F4D0492DC33216A16CC1";
	String topPathPub = null;
	String storage = null;
	String resources = null;
	String config = null;
	String runarg = null;
	String cache = null;
	String splitter = null;
	String finalTopPath = null;
	String variables = null;
	String firstRunFlagFile = null;
	String higherPath1 = null;
	String higherPath2 = null;
	String default_param = null;
	String signatureFile = null;
	String systemPart = null;
	String process = null;
	String boot = null;
	String sysconf = null;
	public LibraryManager(){}
	public void genAllDir(){
		File manu = new File(higherPath1);
		File name = new File(higherPath2);
		File vers = new File(topPathPub);
		File stor = new File(storage);
		File resr = new File(resources);
		File conf = new File(config);
		File cach = new File(cache);
		File vari = new File(variables);
		File btrr = new File(boot);
		File syst = new File(systemPart);
		if(!manu.exists()){
			manu.mkdir();
		}
		if(!name.exists()){
			name.mkdir();
		}
		if(!vers.exists()){
			vers.mkdir();
		}
		if(!stor.exists()){
			stor.mkdir();
		}
		if(!resr.exists()){
			resr.mkdir();
		}
		if(!conf.exists()){
			conf.mkdir();
		}
		if(!cach.exists()){
			cach.mkdir();
		}
		if(!vari.exists()){
			vari.mkdir();
		}
		if(!btrr.exists()){
			btrr.mkdir();
		}
		if(!syst.exists()){
			syst.mkdir();
		}
	}
	public String initiate(String splitter_get, String userDir, String programManu, String programName, String programVers, String defaultParam){
		splitter = splitter_get;
		default_param = defaultParam;
		higherPath1 = userDir + splitter + programManu;
		higherPath2 = higherPath1 + splitter + programName;
		topPathPub = higherPath2 + splitter + programVers;
		storage = topPathPub + splitter + "storage";
		resources = topPathPub + splitter + "resources";
		config = topPathPub + splitter + "config";
		runarg = config + splitter + "bootOptionArguments.mldy";
		sysconf = config + splitter + "setting.mldy";
		cache = topPathPub + splitter + "cache";
		variables = storage + splitter + "var";	
		systemPart = storage + splitter + "system";	
		boot = resources + splitter + "boot";	
		signatureFile = systemPart + splitter + "firmwareSignature.mldy";	
		checkFileExistance();
		firstRunMgr();
		String rc = readConfig();
		return rc;
	}
	public void setVariable(){
		storage = topPathPub + splitter + "storage";
		resources = topPathPub + splitter + "resources";
		config = topPathPub + splitter + "config";
		runarg = config + splitter + "bootOptionArguments.mldy";
		sysconf = config + splitter + "setting.mldy";
		cache = topPathPub + splitter + "cache";
		variables = storage + splitter + "var";	
		boot = resources + splitter + "boot";
	}
	public void firstRunMgr(){
		try{
			process = "Entered First Run Manager";
			genAllDir();
			File firstrun = new File(variables + splitter + "_firstRunFinished");
			File argumentFile = new File(runarg);
			File configuration = new File(sysconf);
			File signature = new File(signatureFile);
			if(!firstrun.exists()){
				process = "Writing: First Run Flag";
				String temp = variables + splitter + "_firstRunFinished";
				WriteFile writer = new WriteFile();
				writer.initiate(temp, " ");
			}
			if(!argumentFile.exists()){
				process = "Writing: Argument Container File";
				WriteFile writer = new WriteFile();
				writer.initiate(runarg, default_param);
			}
			if(!configuration.exists()){
				process = "Writing: Preference file";
				WriteFile writer = new WriteFile();
				writer.initiate(sysconf, "<HEAD>checkOfficialSignature=true<SEP>lockRootOption=true");
			}
			if(!signature.exists()){
				process = "Writing: signature file";
				WriteFile writer = new WriteFile();
				writer.initiate(signatureFile, "CBED2FD52CED6D52973A92C7AC393C83B9272A8BCAB0F4D0492DC33216A16CC1");
			}
		}catch(Exception e){
			ErrorAnalyzer ea = new ErrorAnalyzer();
			ea.initiate(e, process, false);
			System.out.print("Exit? Y/N");
			Scanner input = new Scanner (System.in);
			String s = input.nextLine();
			s = s.toString();
			if(s.equals("y")){
				System.exit(0);
			}
		}
	}
	public void checkFileExistance(){
		ErrorAnalyzer ea = new ErrorAnalyzer();
		if(topPathPub.equals(null)){
			handleTopPathPubNull();
		}else{
			try{
				process = "Check file exists";
				File f_higher1 = new File(higherPath1);
				File f_higher2 = new File(higherPath2);
				File f_topPath = new File(topPathPub);
				File f_storage = new File(storage);
				File f_resources = new File (resources);
				File f_config = new File(config);
				File f_cache = new File(cache);
				File f_var = new File(variables);
				File f_boot = new File(boot);
				if(!f_higher1.exists()){
					f_higher1.mkdir();
					f_higher2.mkdir();
					if(f_topPath.exists()){
						print("Top Path already exists.");
						if(f_topPath.list().length>0){
							}else{
								print("Generating inner library!");
								try{
									process = "Generate inner library";
									f_storage.mkdir();
									f_cache.mkdir();
									f_resources.mkdir();
									f_config.mkdir();
									f_var.mkdir();
									f_boot.mkdir();
								}catch(Exception e){
									ea.initiate(e, process, false);
								}
							}
					}else{
						print("Generating total library!");
						try{
							process = "Generate total library";
							f_topPath.mkdir();
							f_storage.mkdir();
							f_resources.mkdir();
							f_cache.mkdir();
							f_config.mkdir();
							f_boot.mkdir();
							f_var.mkdir();
						}catch(Exception e){
							ea.initiate(e, process, false);
							error("It seems that the higher directory does not exists.");
						}
					}
				}
			}catch(Exception e){
				ea.initiate(e, process, false);
			}
		}
	}
	public String readConfig(){
		String data = null;
		process = "Read Config";
		ErrorAnalyzer ea = new ErrorAnalyzer();
		try{
			File f_config = new File(runarg);
			if(f_config.exists()){
				print("Loading config...");
				ReadFile reader = new ReadFile();
				data = reader.initiate(runarg);
				process = "Analyze read config";
				if(data == null) { 
		            data="nothingInConfigFile";
		        }
			}else{
				data="notAbleToFind";
			}
		}catch(Exception e){
			ea.initiate(e, process, false);
		}
		return data;
	}

	public void handleTopPathPubNull(){
		error("Directory configurations starts with null.");
		print("Please manually enter the Top Path.");
		Scanner input = new Scanner(System.in);
		topPathPub = input.nextLine();
		setVariable();
		checkFileExistance();
	}
	public static void error(String s){
		System.out.println("ERROR [LIBMGR]: " + s);
	}
	public static void print(String s){
		System.out.println("INFO [LIBMGR]: " + s);
	}

}