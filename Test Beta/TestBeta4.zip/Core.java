// Declaration:
// Core version: Test Beta 4
// Package Build: 18B072826UD-TB4
// Copyright (C) Dream Project Group
import java.util.Random;
import java.util.*;
import java.io.*;
public class Core{
	final String hardCodedSignature = "CBED2FD52CED6D52973A92C7AC393C83B9272A8BCAB0F4D0492DC33216A16CC1";
	String path = null;
	boolean secureOption = false;
	String version = null;
	boolean debug = false;
	String splitter = null;	
	ErrorAnalyzer ea = null;
	boolean root = false;
	String storePath = null;
	boolean checkOfficialSignature = true;
	boolean lockRootOption = true;
	String currentDir = null;
	String systemPart = null;
	String firmwareSignatureLocation = null;
	String loadedFirmwareSignature = null;
	public Core(String tempPath, boolean tempSecureOption, String tempVersion, boolean tempDebug, boolean temproot){
		//Copy variables in here
		try{
			ea = new ErrorAnalyzer();
			path = tempPath;
			secureOption = tempSecureOption;
			version = tempVersion;
			debug = tempDebug;
			OSReader getSplitter = new OSReader();
			String[] temp1 = getSplitter.initiate();
			splitter = temp1[0];
			root = temproot;
			storePath = path + "storage" + splitter; 
			currentDir = storePath;
			systemPart = storePath + "system" + splitter;
			firmwareSignatureLocation = systemPart + "firmwareSignature.mldy";
			loadPreferences();
		}catch(Exception e){
			ea.initiate(e, "Core Constructor", debug);
		}
	}
	public void loadPreferences(){
		try{
			String pref = path + "config" + splitter + "setting.mldy";
			ReadFile rf = new ReadFile();
			String raw = rf.initiate(pref);
			String parse[] = raw.split("<SEP>");
			if(!parse[0].startsWith("<HEAD>")){
				print("ERROR [PREFLOAD]: Broken preference. Please repair.");
				endOS();
			}
			if(parse[0].contains("checkOfficialSignature=true")){
				checkOfficialSignature=true;
			}else if(parse[0].contains("checkOfficialSignature=false")){
				checkOfficialSignature=false;
			}else{
				print("WARNING [CORE]: checkOfficialSignature option is broken. Using default value...");
				checkOfficialSignature=true;
			}
			if(parse[1].equals("lockRootOption=true")){
				lockRootOption=true;
			}else if(parse[1].equals("lockRootOption=false")){
				lockRootOption=false;
			}else{
				lockRootOption=true;
				print("WARNING [CORE]: checkOfficialSignature option is broken. Using default value...");
			}
			loadedFirmwareSignature = loadSig();
			if(checkOfficialSignature){
				if(!loadedFirmwareSignature.equals(hardCodedSignature)){
					print("ERROR [CORE]: Authorization failure.");
					endOS();
				}
			}else{
				print("WARNING [CORE]: Official signature check is off. Please enable it to protect from copycats.");
			}
		}catch(Exception e){
			ea.initiate(e, "loadPreferences", debug);
		}
	}
	public String loadSig(){
		ReadFile rf = new ReadFile();
		String data = rf.initiate(firmwareSignatureLocation);
		return data;
	}
	public void initiate(){
		print("INFO [CORE]: Boot complete: " + version);
		if(root){
			secureOption = true;
		}
		if(!secureOption){
			Shield shield = new Shield(path, secureOption);
			home();
		}else{
			if(root){
				secureOption = false;
			}
			home();
		}
	}
	public void home(){
		print("Type fasthelp to see available commands.");
		try{
			Scanner input = new Scanner (System.in);
			String in = null;
			for(;;){
				System.out.print(">");
				in = input.nextLine();
				if(in.equals("shutdown")){
					endOS();
				}else if (in.equals("fasthelp")) {
					fastHelp();
				}else if(in.startsWith("write")){
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: write [file name] [contents]");
					}else{
						if(in.contains(";")){
							//Boot option setting
							String inParse[] = in.split(" ");
							String inParse2[] = in.split(";");
							String writerData = inParse2[1];
							int leng = inParse.length; 
							if(leng==11){
								write(inParse[1], writerData);
							}else{
								print("Wrong format!");
								print("Usage: write dream.bootOption.mldy ; -debug [true/false] -verbose [true/false] -secureOption [true/false] -customBootHashSet [String / null]");
							}
						}else{
							String inParse[] = in.split(" ");
							int leng = inParse.length; 
							if(leng==3){
								write(inParse[1], inParse[2]);
							}else{
								print("Wrong format!");
								print("Usage: write [file name] [contents]");
							}

						}
					}
				}else if(in.startsWith("fs")){
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: fs [option name]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							fs(inParse[1]);
						}else{
							print("Wrong format!");
							print("Usage: fs [option name] [new value]");
						}
					}
				}else if(in.startsWith("list")){
					if(in.contains(" ")){
						print("Wrong format!");
						print("Usage: list");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==1){
							list();
						}else{
							print("Wrong format!");
							print("Usage: list");
						}
					}
				}else if(in.startsWith("reboot")){
					reboot();
				}else if(in.startsWith("read")){
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: read [file name]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							read(inParse[1]);
						}else{
							print("Wrong format!");
							print("Usage: read [file name]");
						}
					}
				}else if(in.startsWith("cd")){
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: cd [directory name]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							cd(inParse[1]);
						}else{
							print("Wrong format!");
							print("Usage: cd [directory name]");
						}
					}
				}else if(in.startsWith("mkdir")){
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: mkdir [directory name]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							mkdir(inParse[1]);
						}else{
							print("Wrong format!");
							print("Usage: mkdir [directory name]");
						}
					}
				}else if(in.startsWith("delete")){
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: delete [file name]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							delete(inParse[1], false);
						}else if(leng==3){
							if(inParse[1].equals("-d")){
								delete(inParse[2], true);
							}else{
								print("Unknown option.");
							}
						} else{
							print("Wrong format!");
							print("Usage: delete (-d) [file name]");
						}
					}
				}else if(in.startsWith("help")){
					help();
				}else if(in.startsWith("var")){
					if(debug){
						if(in.contains(" ")){
							String inParse[] = in.split(" ");
							int leng = inParse.length; 
							if(leng==1){
								var();
							}else{
								print("Wrong format!");
								print("Usage: var");
							}
						}else{
							print("Wrong format!");
							print("Usage: var");
						}
					}else{
						print("Unknown command: " + in);
					}
				}else{
					if(in.contains(" ")){
						String[] unknownCommandEntered = in.split(" ");
						print("Unknown command: " + unknownCommandEntered[0]);
					}else{
						print("Unknown command: " + in);
					}
					
				}
			}
		}catch(Exception e){
			ea.initiate(e, "Core", debug);
		}
	}
	public void var(){
		print("path: " + path);
		print("secureOption: " + secureOption);
		print("version: " + version);
		print("debug: " + debug);
		print("splitter: " + splitter);
		print("root: " + root);
		print("storePath: " + storePath);
		print("checkOfficialSignature: " + checkOfficialSignature);
		print("lockRootOption: " + lockRootOption);
		print("currentDir: " + currentDir);
		print("firmwareSignature: " + loadedFirmwareSignature);
	}
	public void read(String name){
		try{
			if(name.equals("dream.setting.mldy")){
				print("Default value: ");
				print("<HEAD>checkOfficialSignature=true<SEP>lockRootOption=true");
				print("Your current setting: ");
				ReadFile rf = new ReadFile();
				String writingTarget = path + "config" + splitter + "setting.mldy";
				String currentSetup = rf.initiate(writingTarget);
				print(currentSetup);
			}else if(name.equals("dream.bootOption.mldy")){
				print("Default value: ");
				print(" -debug false -verbose false -secureOption true -customBootHashSet null");
				print("Your current setting: ");
				ReadFile rf = new ReadFile();
				String writingTarget = path + "config" + splitter + "bootOptionArguments.mldy";
				String currentSetup = rf.initiate(writingTarget);
				print(currentSetup);
			}else{
				String readingTarget = currentDir + name;
				ReadFile rf = new ReadFile();
				String returned = rf.initiate(readingTarget);
				print(returned);
			}
		}catch(Exception e){
			ea.initiate(e, "read", debug);
		}
	}
	public void fs(String option){
		try{
			Shield shield = new Shield(path, secureOption);
			String fsver = shield.version;
			print("VERSION: " + fsver);
			if(option.equals("resetPW")){
				shield.chpw();
			}else if(option.equals("removePasswordContainer")){
				shield.delUser();
			}else{	
				print("Commands:");
				print("resetPW");
				print("removePasswordContainer");
			}
		}catch(Exception e){
			ea.initiate(e, "fs", debug);
		}
	}
	public void write(String name, String contents){
		try{
			if(name.equals("dream.setting.mldy")){
				String writingTarget = path + "config" + splitter + "setting.mldy";
				WriteFile wf = new WriteFile();
				wf.initiate(writingTarget, contents);
			}else if(name.equals("dream.bootOption.mldy")){
				String writingTarget = path + "config" + splitter + "bootOptionArguments.mldy";
				WriteFile wf = new WriteFile();
				wf.initiate(writingTarget, contents);
			}else{
				String writingTarget = currentDir + name;
				WriteFile wf = new WriteFile();
				wf.initiate(writingTarget, contents);
			}
		}catch(Exception e){
			ea.initiate(e, "write", debug);
		}
	}	
	public void delete(String name, boolean dir){
		try{
			if(dir){
				String deletingTarget = currentDir + name;
				File f = new File(deletingTarget);
				if(!f.isDirectory()){
					print(name + " is not a directory.");
				}else{
					DeleteFolder df = new DeleteFolder();
					df.initiate(deletingTarget);
				}
			}else{
				String deletingTarget = currentDir + name;
				File f = new File(deletingTarget);
				if(f.isDirectory()){
					print(name + " is a directory.");
				}else{
					DeleteFile df = new DeleteFile();
					df.initiate(deletingTarget, false);
				}
			}
		}catch(Exception e){
			ea.initiate(e, "delete", debug);
		}
	}
	public void help(){
		try{
			if(root==true){
				print("WARNING! This firmware is unlocked. The security is disabled.");
			}
			print("shutdown:  Stop OS");
			print("write:  Write text file or make modification to setting file");
			print("fs:  Edit Shield setting");
			print("read:  Read text file");
			print("fasthelp:  Brief command list");
			print("help:  Detailed command list");
			print("delete:  Delete file");
			print("list: list files");
			print("help:  Detailed command list");
			print("cd: Enter to a directory");
			print("reboot: Restart OS");
			if(debug==true){
				print("[DEBUG] var:  See/modify variables");
			}
		}catch(Exception e){
			ea.initiate(e, "help", debug);
		}
	}
	public void cd(String directory){
		try{
			if(directory.equals("~")){
				currentDir = storePath;
			}else if(directory.equals("system")){
				if(!root){
					print("Unable to enter directory: system");
					print("Not enough permission!");
				}else{
					currentDir = storePath + "system" + splitter;
				}
			}else if(directory.equals("var")){
				if(!root){
					print("Unable to enter directory: var");
					print("Not enough permission!");
				}else{
					currentDir = storePath + "var" + splitter;
				}
			}else if(directory.equals("protection")){
				if(!root){
					print("Unable to enter directory: protected");
					print("Not enough permission!");
				}else{
					currentDir = storePath + "protected" + splitter;
				}
			}else{
				String backup = currentDir;
				currentDir = currentDir + directory + splitter;
				File existance = new File(currentDir);
				if(!existance.exists()){
					print("No such file or directory.");
					currentDir = backup;
				}else{
					if(!existance.isDirectory()){
						print(directory + " is not a directory.");
						currentDir = backup;
					}
				}
			}
		}catch(Exception e){
			ea.initiate(e, "cd", debug);
		}
	}
	public void mkdir(String directory){
		try{
			if(directory.startsWith(".")){
				print("Not able to make system directory.");
			}else if(directory.startsWith("~")){
				print("Not able to make system directory.");
			}else{
				MakeDir md = new MakeDir();
				md.initiate(currentDir + directory);
			}
		}catch(Exception e){
			ea.initiate(e, "mkdir", debug);
		}
	}
	public void reboot(){
		try{
			Main main = new Main();
			File cache = new File(path + "resources" + splitter + "boot" + splitter + "systemCache.sc");
			if(cache.delete()){}else{print("WARNING [CORE]: Cache delete was unsuccessful.");}
			main.reboot();
		}catch(Exception e){
			ea.initiate(e, "reboot", debug);
		}
	}	
	public void fastHelp(){
		try{
			if(root==true){
				print("WARNING! This firmware is unlocked. The security is disabled.");
			}
			print("shutdown");
			print("write");
			print("fs");
			print("read");
			print("fasthelp");
			print("help");
			print("delete");
			print("cd");
			print("reboot");
			if(debug==true){
				print("[DEBUG] var");
			}
		}catch(Exception e){
			ea.initiate(e, "fasthelp", debug);
		}
	}
	public void list(){
		try{
			File file = new File(currentDir);
			File[] list = file.listFiles();
			String[] fileList = new String[list.length];
			for(int a=0; a<list.length; a++){
				if(list[a].isDirectory()){
					fileList[a] = "[DIR] " + list[a].getName();
				}else{
					fileList[a] = "[FILE] " + list[a].getName();
				}
				print(fileList[a]);
			}
		}catch(Exception e){
			ea.initiate(e, "list", debug);
		}
	}
	public void endOS(){
		print("Shutting down OS!");
		try{
			File cache = new File(path + "resources" + splitter + "boot" + splitter + "systemCache.sc");
			if(cache.delete()){}else{print("WARNING [CORE]: Cache delete was unsuccessful.");}
			System.exit(0);
		}catch(Exception e){
			ea.initiate(e, "endOS", debug);
			System.exit(0);
		}
	}
	public static void print(String s){
		System.out.println(s);
	}
}