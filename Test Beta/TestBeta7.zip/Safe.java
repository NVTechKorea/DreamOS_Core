// Declaration:
// safeOS version: Test Beta 7
// Package Build: 18B073127UD-TB7
// Copyright (C) Dream Project Group
public class Safe{
	public Safe(){}
	public void registerVar(){

	}
}