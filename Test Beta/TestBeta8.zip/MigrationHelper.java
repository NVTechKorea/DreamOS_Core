// Declaration:
// DreamOS Migration Helper version: Test Beta 8
// Package Build: 18B080552UD-TB8
// Copyright (C) Dream Project Group
public class MigrationHelper{
	public MigrationHelper(){}
	public void registerVar(){

	}
}