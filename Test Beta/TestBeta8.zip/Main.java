// Declaration:
// DreamOS - Main version: Test Beta 8
// Package Build: 18B080552UD-TB8
// Copyright (C) Dream Project Group
import java.util.Random;
public class Main{
	final static String programManu = "DreamProjectGroup";
	final static String programName = "DreamOS";
	final static String programVers = "Beta8";
	static String nameOfOS = null;
	static String userDir = null;
	static String dirSplitter = null;
	static String filePath = null;
	static final String hardCodedSignature = "B1C088E57ED6EDF3AD412AE992292F0C3CEC14640D27AF239CF0D8D1CC273E0A";
	static String default_param=" -debug false -verbose false -secureOption true -customBootHashSet " + hardCodedSignature;
	public Main(){};
	public static void main(String[] args) {
		print("Started...");
		Parser parser = new Parser();
		print("Parser loaded.");
		LibraryManager libmanager = new LibraryManager();
		print("File Manager loaded.");
		print("Get OS information...");
		getOSNameAndPath();
		print("Loading configurations...");
		String param=libmanager.initiate(dirSplitter, userDir, programManu, programName, programVers, default_param);
		if(param.equals("notAbleToFind")){
			error("Unable to load configuration. Code: INVALID_CONFIG_LOC");
			print("Temporarily using default.");
			param = default_param;
		}
		if(param.equals("nothingInConfigFile")){
			error("Unable to load configuration. Code: RETURNED_STRING_EMPTY");
			print("Temporarily using default.");
			param = default_param;
		}
		parser.parseMainParam(param, programVers, filePath);
	}
	public static void reboot(){
		print("Started...");
		Parser parser = new Parser();
		print("Parser loaded.");
		LibraryManager libmanager = new LibraryManager();
		print("File Manager loaded.");
		print("Get OS information...");
		getOSNameAndPath();
		print("Loading configurations...");
		String param=libmanager.initiate(dirSplitter, userDir, programManu, programName, programVers, default_param);
		if(param.equals("notAbleToFind")){
			error("Unable to load configuration. Code: INVALID_CONFIG_LOC");
			print("Temporarily using default.");
			param = default_param;
		}
		if(param.equals("nothingInConfigFile")){
			error("Unable to load configuration. Code: RETURNED_STRING_EMPTY");
			print("Temporarily using default.");
			param = default_param;
		}
		parser.parseMainParam(param, programVers, filePath);
	}
	public static void getOSNameAndPath(){
		OSReader osreader = new OSReader();
		String data[] = osreader.initiate();
		nameOfOS = data[1];
		userDir = data[2];
		dirSplitter = data[0];
		filePath = userDir + dirSplitter + programManu + dirSplitter + programName + dirSplitter + programVers;
	}
	public static void error(String s){
		System.out.println("ERROR [MAIN]: " + s);
	}
	public static void print(String s){
		System.out.println("INFO [MAIN]: " + s);
	}
	public static void exit(int val){
		System.out.println("EXIT [MAIN]: Exiting program.");
		System.exit(val);
	}

}