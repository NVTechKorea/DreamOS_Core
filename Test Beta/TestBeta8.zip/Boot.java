// Declaration:
// Boot version: Test Beta 8
// Package Build: 18B080552UD-TB8
// Copyright (C) Dream Project Group
import java.util.Random;
import java.util.Scanner;
import java.io.File;
public class Boot{
	boolean verbose = false;
	boolean secureOption = true;
	boolean debug = false;
	String highPath = null;
	String bootHash = null;
	String splitter = null;
	String version = null;
	boolean root = false;
	public Boot(boolean temp1, boolean temp2, boolean temp3, String temp4, String temp5, String temp6, String temp8){
		verbose = temp1;
		secureOption = temp2;
		debug = temp3;
		OSReader getSplitter = new OSReader();
		String[] temp7 = getSplitter.initiate();
		splitter = temp7[0];
		highPath = temp4 + splitter;
		bootHash = temp5;
		version = temp6;
		if(temp8.equals("true")){
			root = true;
		}
	}
	public void initiate(){
		print("Bootloader .init initiated.");
		if(verbose){
			init_verbose();
		}else{
			String bootOption = "default";
			File tempFile = new File(highPath + "resources" + splitter + "boot" + splitter + "systemCache.sc");
			if(tempFile.exists()){
				warn("It seems your system has shutdown improperly.");
				print("Would you boot into different system?");
				print("1. Default");
				print("2. Recovery");
				print("3. Safe Mode");
				for(;;){
					Scanner input = new Scanner (System.in);
					String temp2 = input.nextLine();
					if(temp2.contains("1")){
						print("Entering: Default");
						bootOption = "default";
						break;
					}else if(temp2.contains("2")){
						print("Entering: Recovery");
						bootOption = "recovery";
						break;
					}else if(temp2.contains("3")){
						print("Entering: Safe Mode");
						bootOption = "safemode";
						break;
					}else{
						error("Wrong option!");
					}
				}
			}else{
				WriteFile wf = new WriteFile();
				wf.initiate(highPath + "resources" + splitter + "boot" + splitter + "systemCache.sc", "BootInitiated");
			}
			if(bootOption.contains("default")){
				if(secureOption){
					print("Secure boot is enabled.");
					Shield shield = new Shield(highPath, secureOption);
					shield.initiate();
				}else{
					warn("Secure boot is disabled.");
					Shield shield = new Shield(highPath, secureOption);
					shield.initiate();
				}
				DreamOS_Core core = new DreamOS_Core(highPath, secureOption, version, debug, root, bootHash);
				core.initiate();
			}else if(bootOption.contains("safemode")){
				DeltaOS safe = new DeltaOS();
				safe.registerVar(highPath, version, splitter);
				safe.safeOS();
			}else if(bootOption.contains("recovery")){
				DeltaOS recovery = new DeltaOS();
				recovery.registerVar(highPath, version, splitter);
				recovery.recoveryOS();
			}else{
				error("Wrong boot option...");
			}
		}
	}
	public void init_verbose(){
		String bootOption = "default";
		print("Default boot option is: " + bootOption);
		File tempFile = new File(highPath + "resources" + splitter + "boot" + splitter + "systemCache.sc");
		print("Checking whether system shutted down properly...");
		if(tempFile.exists()){
			warn("It seems your system has shutted down improperly.");
			print("Would you boot into different system?");
			print("1. Default");
			print("2. Recovery");
			print("3. Safe Mode");
			for(;;){
				Scanner input = new Scanner (System.in);
				print("Waiting for input...");
				String temp2 = input.nextLine();
				if(temp2.contains("1")){
					print("Default mode selected...");
					print("Entering: Default");
					bootOption = "default";
					break;
				}else if(temp2.contains("2")){
					print("Recovery mode selected...");
					print("Entering: Recovery");
					bootOption = "recovery";
					break;
				}else if(temp2.contains("3")){
					print("Safe mode selected...");
					print("Entering: Safe Mode");
					bootOption = "safemode";
					break;
				}else{
					error("User input: " + temp2 + " does not exist in navigator.");
					error("Wrong option!");
				}
			}
		}else{
			print("Confirmed system shutted down properly.");
			print("Writing cache file...");
			String tempPath = highPath + "resources" + splitter + "boot" + splitter + "systemCache.sc";
			WriteFile wf = new WriteFile();
			wf.initiate(tempPath, "BootInitiated");
			print("Cache file was written in: " + tempPath);
		}
		print("Checking for secure option...");
		if(bootOption.contains("default")){
			if(secureOption){
				print("Secure boot is enabled.");
				print("Executing shield...");
				Shield shield = new Shield(highPath, secureOption);
				shield.initiate();
			}else{
				warn("Secure boot is disabled.");
				Shield shield = new Shield(highPath, secureOption);
				shield.initiate();
			}
			print("Launching system!");
			DreamOS_Core core = new DreamOS_Core(highPath, secureOption, version, debug, root, bootHash);
			core.initiate();
		}else if(bootOption.contains("safemode")){
			print("Launching system!");
			DeltaOS safe = new DeltaOS();
			safe.registerVar(highPath, version, splitter);
			safe.safeOS();
		}else if(bootOption.contains("recovery")){
			print("Launching system!");
			DeltaOS recovery = new DeltaOS();
			recovery.registerVar(highPath, version, splitter);
			recovery.recoveryOS();
		}else{
			print("No such boot option found...");
			error("Wrong boot option...");
		}
	}
	public static void print(String s){
		System.out.println("INFO [BOOT]: " + s);
	}
	public static void warn(String s){
		System.out.println("WARNING [BOOT]: " + s);
	}
	public static void error(String s){
		System.out.println("ERROR [BOOT]: " + s);
	}
}