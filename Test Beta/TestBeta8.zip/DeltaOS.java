// Declaration:
// deltaOS version: Test Beta 8
// Package Build: 18B080552UD-TB8
// Copyright (C) Dream Project Group
import java.util.Scanner;
import java.io.*;
public class DeltaOS{
	String path = null;
	String version = null;
	boolean debug = true;
	String splitter = null;	
	ErrorAnalyzer ea = null;
	String storePath = null;
	String beforeDir = null;
	String currentDir = null;
	final String hardCodedSignature = "B1C088E57ED6EDF3AD412AE992292F0C3CEC14640D27AF239CF0D8D1CC273E0A";
	final String bootarg = " -debug false -verbose false -secureOption true -customBootHashSet " + hardCodedSignature;
	final String configuration = "<HEAD>checkOfficialSignature=true<SEP>lockRootOption=true";
	public DeltaOS(){}
	public void registerVar(String tpath, String tversion, String tsplitter){
		path=tpath;
		version=tversion;
		splitter=tsplitter;
		ea = new ErrorAnalyzer();
		storePath = path + splitter + "storage" + splitter;
		currentDir = storePath;
	}
	public void deltaOS(String director){
		if(director.equals("safe")){
			safeOS();
		}else if(director.equals("recovery")){
			recoveryOS();
		}else{
			error("director is null.");
			safeOS();
		}
	}
	public void safeOS(){	
		print("deltaOS " + version);
		print("Entering deltaOS.safeOS");
		try{
			Scanner input = new Scanner(System.in);
			for(;;){	
				System.out.print("safeOS@deltaOS_Core: > ");
				String usr = input.nextLine();
				if(usr.equals("recovery")){
					recoveryOS();
				}else if(usr.startsWith("write")){
					if(!usr.contains(" ")){
						print("Wrong format!");
						print("Usage: write [file name]:[contents]");
					}else{
						String inParse[] = usr.split(" ");
						int leng = inParse.length; 
						if(leng>=3){
							String contents[] = usr.split(":");
							String getName[] = contents[0].split(" ");
							write(getName[1], contents[1]);
						}else{
							print("Wrong format!");
							print("Usage: write [file name]:[contents]");
						}
					}
				}else if(usr.startsWith("read")){
					if(!usr.contains(" ")){
						print("Wrong format!");
						print("Usage: read [file name]");
					}else{
						String inParse[] = usr.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							read(inParse[1]);
						}else{
							print("Wrong format!");
							print("Usage: read [file name]");
						}
					}
				}else if(usr.startsWith("cd")){
					if(!usr.contains(" ")){
						print("Wrong format!");
						print("Usage: cd [directory name]");
					}else{
						String inParse[] = usr.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							cd(inParse[1]);
						}else{
							print("Wrong format!");
							print("Usage: cd [directory name]");
						}
					}
				}else if(usr.startsWith("delete")){
					if(!usr.contains(" ")){
						print("Wrong format!");
						print("Usage: delete [file name]");
					}else{
						String inParse[] = usr.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							deleteFile(inParse[1], false);
						}else if(leng==3){
							if(inParse[1].equals("-d")){
								deleteFile(inParse[2], true);
							}else{
								print("Unknown option.");
							}
						} else{
							print("Wrong format!");
							print("Usage: delete (-d) [file name]");
						}
					}
				}else if(usr.startsWith("shutdown")){
					deleteFile(path + "resources" + splitter + "boot" + splitter + "systemCache.sc", true);
					System.exit(0);
				}else if(usr.startsWith("help")){
					print("cd: Enter a directory");
					print("delete: Delete a file or directory");
					print("help: Show this message");
					print("list: List files and directories");
					print("read: Read a file");
					print("recovery: Enter recoveryOS");
					print("shutdown: Shutdown safeOS");
					print("write: Write a file");
				}else if(usr.equals("list")){
					list();
				}else{
					error("No such command.");
				}
			}
		}catch(Exception e){
			ea.initiate(e, "safe", true);
			print("Exiting deltaOS...");
			System.exit(0);
		}
	}
	public void recoveryOS(){
		print("deltaOS " + version);
		print("Entering deltaOS.recoveryOS");
		try{
			Scanner input = new Scanner(System.in);
			for(;;){	
				System.out.print("recoveryOS@deltaOS_Core: > ");
				String usr = input.nextLine();
				if(usr.equals("resign")){
					deleteFile(storePath + "system" + splitter + "firmwareSignature.mldy",true);
					print("Previous firmware signature is removed.");
					writeFile(storePath + "system" + splitter + "firmwareSignature.mldy", hardCodedSignature);
					print("Firmware resigned.");
				}else if(usr.equals("resetpw")){
					print("Accessing FusionShield...");
					Shield shield = new Shield(path, true);
					String fsver = shield.version;
					print("VERSION: " + fsver);
					shield.chpw();
				}else if(usr.equals("help")){
					print("resetboot: Reset boot configuration");
					print("resetpref: Reset preferences");
					print("resign: Rewrite signature with stock signature");
					print("help: Show this message");
					print("resetpw: Reset Shield password");
					print("safe: enter safeOS");
					print("shutdown: Shutdown recoveryOS");
				}else if(usr.equals("resetboot")){
					deleteFile(path + "config" + splitter + "bootOptionArguments.mldy", true);
					writeFile(path + "config" + splitter + "bootOptionArguments.mldy", bootarg);
					print("Boot config resetted.");
				}else if(usr.equals("resetpref")){
					deleteFile(path + "config" + splitter + "setting.mldy", true);
					writeFile(path + "config" + splitter + "setting.mldy", configuration);
					print("Preferences resetted.");
				}else if(usr.equals("shutdown")){
					deleteFile(path + "resources" + splitter + "boot" + splitter + "systemCache.sc", true);
					System.exit(0);
				}else if(usr.equals("safe")){
					safeOS();
				}else{
					error("No such command.");
				}
			}
		}catch(Exception e){
			ea.initiate(e, "recovery", true);
			print("Exiting deltaOS...");
			System.exit(0);
		}
	}
	public void print(String s){
		System.out.println("INFO [DeltaOS]: " + s);
	}
	public void warn(String s){
		System.out.println("WARNING [DeltaOS]: " + s);
	}
	public void error(String s){
		System.out.println("ERROR [DeltaOS]: " + s);
	}
	public void deleteFile(String path, boolean silent){
		File file = new File(path);
		if(file.delete()){
			if(!silent){
				System.out.println("Successfully deleted: " + path);
			}
		}else{
			System.out.println("Deleting failure: " + path);
		}
	}
	public void deleteFolder(String path){
		File file = new File(path);
		File[] list = file.listFiles();
		for(int a=0; a<list.length; a++){
			if(list[a].isDirectory()){
				System.out.println("There is a directory inside this directory.");
			}else{
				if(list[a].delete()){
				}else{
					System.out.println("Deleting failure: " + path);
				}
			}
		}
		if(file.delete()){}else{System.out.println("Deleting failure: " + path);}
	}
	public void writeFile(String path, String contents){
		String process = "Writing file: " + path;
		Writer writer = null;
		try{
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path), "utf-8"));
			writer.write(contents);
		}catch(Exception e){
			System.out.println("ERROR [WRITER]");
			ErrorAnalyzer ea = new ErrorAnalyzer();
			ea.initiate(e, process, false);
		}finally {
			try {
				writer.close();
			} catch (Exception ex) {
				System.out.println("ERROR");
			}
		}
	}
	public void read(String name){
		try{
			String readingTarget = currentDir + name;
			ReadFile rf = new ReadFile();
			String returned = rf.initiate(readingTarget);
			print(returned);
		}catch(Exception e){
			ea.initiate(e, "read", debug);
		}
	}
	public void write(String name, String contents){
		try{
			if(name.equals("bootOptionArguments.mldy")){
				print("Unable to overwrite boot option with write command.");
			}else if(name.equals("setting.mldy")){
				print("Unable to overwrite setting with write command.");
			}else{
				String writingTarget = currentDir + name;
				WriteFile wf = new WriteFile();
				wf.initiate(writingTarget, contents);
			}
		}catch(Exception e){
			ea.initiate(e, "write", debug);
		}
	}	
	public void cd(String directory){
		try{
			beforeDir = currentDir;
			if(directory.equals("~")){
				currentDir = storePath;
			}else{
				String backup = currentDir;
				currentDir = currentDir + directory + splitter;
				File existance = new File(currentDir);
				if(!existance.exists()){
					print("No such file or directory.");
					currentDir = backup;
				}else{
					if(!existance.isDirectory()){
						print(directory + " is not a directory.");
						currentDir = backup;
					}
				}
			}
		}catch(Exception e){
			ea.initiate(e, "cd", debug);
		}
		if(!currentDir.startsWith(path)){
			print("You are already in root directory.");
		}
	}
	public void list(){
		try{
			File file = new File(currentDir);
			File[] list = file.listFiles();
			String[] fileList = new String[list.length];
			for(int a=0; a<list.length; a++){
				if(list[a].isDirectory()){
					fileList[a] = "[DIR] " + list[a].getName();
				}else{
					fileList[a] = "[FILE] " + list[a].getName();
				}
				print(fileList[a]);
			}
		}catch(Exception e){
			ea.initiate(e, "list", debug);
		}
	}
}