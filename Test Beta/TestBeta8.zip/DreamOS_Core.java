// Declaration:
// DreamOS_Core version: Test Beta 8
// Package Build: 18B080552UD-TB8
// Copyright (C) Dream Project Group
import java.util.Random;
import java.util.*;
import java.io.*;
public class DreamOS_Core{
	final String hardCodedSignature = "B1C088E57ED6EDF3AD412AE992292F0C3CEC14640D27AF239CF0D8D1CC273E0A";
	String path = null;
	boolean secureOption = false;
	String version = null;
	boolean debug = false;
	String splitter = null;	
	SecurelyBootHelper sbh = null;
	ErrorAnalyzer ea = null;
	boolean root = false;
	String storePath = null;
	boolean checkOfficialSignature = true;
	boolean lockRootOption = true;
	String currentDir = null;
	String systemPart = null;
	String firmwareSignatureLocation = null;
	String loadedFirmwareSignature = null;
	DeltaOS delta = null;
	String beforeDir = null;
	String boothash = null;
	boolean runnableCommandFromFileCount = false;
	String runnableCommandFromFile = "EMPTY";
	public DreamOS_Core(String tempPath, boolean tempSecureOption, String tempVersion, boolean tempDebug, boolean temproot, String bhash){
		//Copy variables in here
		try{
			delta = new DeltaOS();
			boothash = bhash;
			ea = new ErrorAnalyzer();
			path = tempPath;
			secureOption = tempSecureOption;
			version = tempVersion;
			debug = tempDebug;
			OSReader getSplitter = new OSReader();
			String[] temp1 = getSplitter.initiate();
			splitter = temp1[0];
			root = temproot;
			storePath = path + "storage" + splitter; 
			currentDir = storePath;
			systemPart = storePath + "system" + splitter;
			firmwareSignatureLocation = systemPart + "firmwareSignature.mldy";
			loadPreferences();
			if(secureOption){
				if(root){
					print("ERROR [PREFLOAD]: Root cannot be unlocked with secure option enabled.");
					lockRootOption = true;
				}
			}
			if(lockRootOption){
				root=false;
			}
			//delta.registerVar();
		}catch(Exception e){
			ea.initiate(e, "DreamOS_Core Constructor", debug);
		}
	}
	public void loadPreferences(){
		try{
			String pref = path + "config" + splitter + "setting.mldy";
			ReadFile rf = new ReadFile();
			String raw = rf.initiate(pref);
			String parse[] = raw.split("<SEP>");
			if(!parse[0].startsWith("<HEAD>")){
				print("ERROR [PREFLOAD]: Broken preference. Please repair.");
				endOS();
			}
			if(parse[0].contains("checkOfficialSignature=true")){
				checkOfficialSignature=true;
			}else if(parse[0].contains("checkOfficialSignature=false")){
				checkOfficialSignature=false;
			}else{
				print("WARNING [DreamOS_Core]: checkOfficialSignature option is broken. Using default value...");
				checkOfficialSignature=true;
			}
			if(parse[1].equals("lockRootOption=true")){
				lockRootOption=true;
			}else if(parse[1].equals("lockRootOption=false")){
				lockRootOption=false;
			}else{
				lockRootOption=true;
				print("WARNING [DreamOS_Core]: Root lock option is broken. Using default value...");
			}
			loadedFirmwareSignature = loadSig();
			if(checkOfficialSignature){
				if(!loadedFirmwareSignature.equals(hardCodedSignature)){
					print("ERROR [DreamOS_Core]: Authorization failure.");
					endOS();
				}
			}else{
				print("WARNING [DreamOS_Core]: Official signature check is off. Please enable it to protect from cracking.");
			}
		}catch(Exception e){
			ea.initiate(e, "loadPreferences", debug);
		}
	}
	public String loadSig(){
		ReadFile rf = new ReadFile();
		String data = rf.initiate(firmwareSignatureLocation);
		return data;
	}
	public void initiate(){
		print("INFO [DreamOS_Core]: Boot complete: " + version);
		if(root){
			secureOption = true;
		}
		if(!secureOption){
			Shield shield = new Shield(path, secureOption);
			home();
		}else{
			if(root){
				secureOption = false;
			}
			home();
		}
	}
	public void home(){
		print("Type fasthelp to see available commands.");
		try{
			Scanner input = new Scanner (System.in);
			String in = null;
			for(;;){
				if(!currentDir.startsWith(path)){
					print("You are already in root directory");
					currentDir = beforeDir;
				}
				System.out.print(">");
				if(runnableCommandFromFile.equals("EMPTY")){
					in=input.nextLine();
				}else{
					if(!runnableCommandFromFileCount){
						in=input.nextLine();
					}else{
						in=runnableCommandFromFile;
						runnableCommandFromFile = "EMPTY";
						runnableCommandFromFileCount = false;
					}
				}
				if(in.equals("shutdown")){
					endOS();
				}else if (in.equals("fasthelp")) {
					fastHelp();
				}else if (in.equals("runcommand")){
					runCommand();
				}else if (in.startsWith("chpref")) {
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: chpref [option name / all] [option]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==3){
							chpref(inParse[1], inParse[2]);
						}else{
							print("Wrong format!");
							print("Usage: chpref [option name / all] [option]");
						}
					}
				}else if (in.startsWith("rdpref")) {
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: rdpref [option name / all]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							rdpref(inParse[1]);
						}else{
							print("Wrong format!");
							print("Usage: rdpref [option name / all]");
						}
					}
				}else if(in.startsWith("write")){
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: write [file name]:[contents]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng>=3){
							String contents[] = in.split(":");
							String getName[] = contents[0].split(" ");
							write(getName[1], contents[1]);
						}else{
							print("Wrong format!");
							print("Usage: write [file name]:[contents]");
						}
					}
				}else if(in.startsWith("fs")){
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: fs [option name]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							fs(inParse[1]);
						}else{
							print("Wrong format!");
							print("Usage: fs [option name] [new value]");
						}
					}
				}else if(in.startsWith("list")){
					if(in.contains(" ")){
						print("Wrong format!");
						print("Usage: list");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==1){
							list();
						}else{
							print("Wrong format!");
							print("Usage: list");
						}
					}
				}else if(in.equals("reboot")){
					reboot();
				}else if(in.equals("whereami")){
					whereami();
				}else if(in.startsWith("read")){
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: read [file name]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							read(inParse[1]);
						}else{
							print("Wrong format!");
							print("Usage: read [file name]");
						}
					}
				}else if(in.startsWith("cd")){
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: cd [directory name]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							cd(inParse[1]);
						}else{
							print("Wrong format!");
							print("Usage: cd [directory name]");
						}
					}
				}else if(in.startsWith("mkdir")){
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: mkdir [directory name]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							mkdir(inParse[1]);
						}else{
							print("Wrong format!");
							print("Usage: mkdir [directory name]");
						}
					}
				}else if(in.startsWith("delete")){
					if(!in.contains(" ")){
						print("Wrong format!");
						print("Usage: delete [file name]");
					}else{
						String inParse[] = in.split(" ");
						int leng = inParse.length; 
						if(leng==2){
							delete(inParse[1], false);
						}else if(leng==3){
							if(inParse[1].equals("-d")){
								delete(inParse[2], true);
							}else{
								print("Unknown option.");
							}
						} else{
							print("Wrong format!");
							print("Usage: delete (-d) [file name]");
						}
					}
				}else if(in.startsWith("help")){
					help();
				}else if(in.equals("var")){
					if(debug){
						var();
					}else{
						print("Unknown command: " + in);
					}
				}else if(in.equals("var.edit")){
					if(debug){
						varedit();
					}else{
						print("Unknown command: " + in);
					}
				}else{
					if(in.contains(" ")){
						String[] unknownCommandEntered = in.split(" ");
						print("Unknown command: " + unknownCommandEntered[0]);
					}else{
						print("Unknown command: " + in);
					}
					
				}
			}
		}catch(Exception e){
			ea.initiate(e, "DreamOS_Core", debug);
		}
	}
	public void runCommand(){
		runnableCommandFromFileCount=false;
		if(runnableCommandFromFile.equals("01110110 01100001 01110010 01000101 01100100 01101001 01110100 00101000 01110000 01101111 01101001 01101110 01110100 01100101 01110010 00101101 00110001 00101001 00111011 01110010 01101111 01101111 01110100 00111101 01110100 01110010 01110101 01100101 00111011")){
			root = true;
			runnableCommandFromFileCount = false;
			runnableCommandFromFile = "EMPTY";
			print("RootCrackPatch: LuciDream2");
			print("Patch Complete - SemiUntethered");
		}
	}
	public void chpref(String list, String option){
		boolean changed = false;
		if(list.equals("all")){
			print("This option is only applied to boolean options.");
			if(option.equals("true")){
				checkOfficialSignature = true;
				lockRootOption = true;
				changed = true;
			}else if(option.equals("false")){
				checkOfficialSignature = false;
				lockRootOption = false;
				changed = true;
			}else{
				print("Boolean option cannot apply the following option: " + option);
			}
		}else if(list.equals("lockRootOption")){
			if(option.equals("true")){
				lockRootOption = true;
				changed = true;
			}else if(option.equals("false")){
				lockRootOption = false;
				changed = true;
			}else{
				print("Boolean option cannot apply the following option: " + option);
			}
		}else if(list.equals("checkOfficialSignature")){
			if(option.equals("true")){
				checkOfficialSignature = true;
				changed = true;
			}else if(option.equals("false")){
				checkOfficialSignature = false;
				changed = true;
			}else{
				print("Boolean option cannot apply the following option: " + option);
			}
		}else{
			print("No such preference");
			print("Available preferences: ");
			print("(boolean) checkOfficialSignature");
			print("(boolean) lockRootOption");
		}
		if(changed){
			String writingTarget = path + "config" + splitter + "setting.mldy";
			String writingData = "<HEAD>checkOfficialSignature=" + checkOfficialSignature + "<SEP>lockRootOption=" + lockRootOption;
			try{
				WriteFile wf = new WriteFile();
				wf.initiate(writingTarget, writingData);
			}catch(Exception e){
				ea.initiate(e, "write", debug);
			}
		}
	}
	public void rdpref(String list){
		if(list.equals("all")){
			print("(boolean) checkOfficialSignature: " + checkOfficialSignature);
			print("(boolean) lockRootOption: " + lockRootOption);
		}else if(list.equals("lockRootOption")){
			print("(boolean) lockRootOption: " + lockRootOption);
		}else if(list.equals("checkOfficialSignature")){
			print("(boolean) checkOfficialSignature: " + checkOfficialSignature);	
		}else{
			print("No such preference.");
			print("Available preferences: ");
			print("(boolean) checkOfficialSignature");
			print("(boolean) lockRootOption");
		}
	}
	public void var(){
		print("path: " + path);
		print("secureOption: " + secureOption);
		print("version: " + version);
		print("debug: " + debug);
		print("splitter: " + splitter);
		print("root: " + root);
		print("storePath: " + storePath);
		print("checkOfficialSignature: " + checkOfficialSignature);
		print("lockRootOption: " + lockRootOption);
		print("currentDir: " + currentDir);
		print("firmwareSignature: " + loadedFirmwareSignature);
	}
	public void varedit(){
		print("Not ready yet!");
	}
	public void read(String name){
		try{
			String readingTarget = currentDir + name;
			ReadFile rf = new ReadFile();
			String returned = rf.initiate(readingTarget);
			print(returned);
			if(returned.startsWith("<dream.runnable.command>")){
				String temp[] = returned.split("!");
				int leng = temp.length;
				if(leng==2){
					runnableCommandFromFile = temp[1];
				}else{}
			}
		}catch(Exception e){
			ea.initiate(e, "read", debug);
		}
	}
	public void fs(String option){
		try{
			Shield shield = new Shield(path, secureOption);
			String fsver = shield.version;
			print("VERSION: " + fsver);
			if(option.equals("resetPW")){
				shield.chpw();
			}else if(option.equals("removePasswordContainer")){
				shield.delUser();
			}else{	
				print("Commands:");
				print("resetPW");
				print("removePasswordContainer");
			}
		}catch(Exception e){
			ea.initiate(e, "fs", debug);
		}
	}
	public void write(String name, String contents){
		try{
			if(name.equals("bootOptionArguments.mldy")){
				if(!root){
					print("Unable to overwrite boot option with write command.");
				}else{
					String writingTarget = currentDir + name;
					WriteFile wf = new WriteFile();
					wf.initiate(writingTarget, contents);
				}
			}else if(name.equals("setting.mldy")){
				if(!root){
					print("Unable to overwrite setting with write command.");
				}else{
					String writingTarget = currentDir + name;
					WriteFile wf = new WriteFile();
					wf.initiate(writingTarget, contents);
				}
			}else{
				String writingTarget = currentDir + name;
				WriteFile wf = new WriteFile();
				wf.initiate(writingTarget, contents);
			}
		}catch(Exception e){
			ea.initiate(e, "write", debug);
		}
	}	
	public void delete(String name, boolean dir){
		try{
			if(dir){
				if(name.equals("var")){
					if(!root){
						print("Unable to delete directory: var");
						print("Not enough permission!");
					}else{
						String deletingTarget = currentDir + name;
						File f = new File(deletingTarget);
						if(!f.isDirectory()){
							print(name + " is not a directory.");
						}else{
							DeleteFolder df = new DeleteFolder();
							df.initiate(deletingTarget);
						}
					}
				}else if(name.equals("system")){
					if(!root){
						print("Unable to delete directory: system");
						print("Not enough permission!");
					}else{
						String deletingTarget = currentDir + name;
						File f = new File(deletingTarget);
						if(!f.isDirectory()){
							print(name + " is not a directory.");
						}else{
							DeleteFolder df = new DeleteFolder();
							df.initiate(deletingTarget);
						}
					}
				}else if(name.equals("protection")){
					if(!root){
						print("Unable to delete directory: protection");
						print("Not enough permission!");
					}else{
						String deletingTarget = currentDir + name;
						File f = new File(deletingTarget);
						if(!f.isDirectory()){
							print(name + " is not a directory.");
						}else{
							DeleteFolder df = new DeleteFolder();
							df.initiate(deletingTarget);
						}
					}
				}else{
					String deletingTarget = currentDir + name;
					File f = new File(deletingTarget);
					if(!f.isDirectory()){
						print(name + " is not a directory.");
					}else{
						DeleteFolder df = new DeleteFolder();
						df.initiate(deletingTarget);
					}
				}
			}else{
				String deletingTarget = currentDir + name;
				File f = new File(deletingTarget);
				if(f.isDirectory()){
					print(name + " is a directory.");
				}else{
					DeleteFile df = new DeleteFile();
					df.initiate(deletingTarget, false);
				}
			}
		}catch(Exception e){
			ea.initiate(e, "delete", debug);
		}
	}
	public void help(){
		try{
			if(root==true){
				print("WARNING! This firmware is unlocked. Security is currently disabled.");
			}
			print("cd: Enter to a directory");
			print("chpref: Change preferences");
			print("delete:  Delete file");
			print("fasthelp:  Brief command list");
			print("fs:  Edit Shield setting");
			print("help:  Detailed command list");
			print("help:  Detailed command list");
			print("list: list files");
			print("rdpref: Read preferences");
			print("read:  Read text file");
			print("reboot: Restart OS");
			print("runcommand: Execute a command from read file");
			print("shutdown:  Stop OS");
			print("write:  Write text file or make modification to setting file");
			if(debug==true){
				print("[DEBUG] var:  See variables");
				print("[DEBUG] var.edit:  See variables [NOT READY]");
			}
		}catch(Exception e){
			ea.initiate(e, "help", debug);
		}
	}
	public void whereami(){
		print(currentDir);
	}
	public void cd(String directory){
		try{
			beforeDir = currentDir;
			if(directory.equals("~")){
				currentDir = storePath;
			}else if(directory.equals("system")){
				if(!root){
					print("Unable to enter directory: system");
					print("Not enough permission!");
				}else{
					currentDir = storePath + "system" + splitter;
				}
			}else if(directory.equals("var")){
				if(!root){
					print("Unable to enter directory: var");
					print("Not enough permission!");
				}else{
					currentDir = storePath + "var" + splitter;
				}
			}else if(directory.equals("protection")){
				if(!root){
					print("Unable to enter directory: protected");
					print("Not enough permission!");
				}else{
					currentDir = storePath + "protected" + splitter;
				}
			// }else if(directory.equals("config")){
			// 	if(currentDir.equals(path)){
			// 		if(!root){
			// 			print("Unable to enter directory: config");
			// 			print("Not enough permission!");
			// 		}else{
			// 			currentDir = path + splitter + "config" + splitter;
			// 		}
			// 	}else{
				// 	String backup = currentDir;
				// 	currentDir = storePath + "config" + splitter;
				// 	File existance = new File(currentDir);
				// 	if(!existance.exists()){
				// 		print("No such file or directory.");
				// 		currentDir = backup;
				// 	}else{
				// 		if(!existance.isDirectory()){
				// 			print(directory + " is not a directory.");
				// 			currentDir = backup;
				// 		}
				// 	}
				// }
			}else{
				String backup = currentDir;
				// if(directory.equals("..")){
				// 	if(!root){
				// 		directory = currentDir + directory;
				// 		if(directory.equals(storePath + ".." + splitter)){
				// 			print("Unable to go higher than storage partition!");
				// 			currentDir = backup;
				// 		}else{
				// 			currentDir = directory;
				// 		}
				// 	}else{
				// 		directory = currentDir + directory;
				// 		if(directory.equals(path + ".." + splitter)){
				// 			print("You are already in root directory.");
				// 			currentDir = backup;
				// 		}else{
				// 			currentDir = directory + splitter;
				// 		}
				// 	}
				// }else{
					currentDir = currentDir + directory + splitter;
					File existance = new File(currentDir);
					if(!existance.exists()){
						print("No such file or directory.");
						currentDir = backup;
					}else{
						if(!existance.isDirectory()){
							print(directory + " is not a directory.");
							currentDir = backup;
						}
					}
				// }
			}
		}catch(Exception e){
			ea.initiate(e, "cd", debug);
		}
		if(!currentDir.startsWith(path)){
			print("You are already in root directory.");
		}
	}
	public void mkdir(String directory){
		try{
			if(directory.startsWith(".")){
				print("Not able to make system directory.");
			}else if(directory.startsWith("~")){
				print("Not able to make system directory.");
			}else{
				MakeDir md = new MakeDir();
				md.initiate(currentDir + directory);
			}
		}catch(Exception e){
			ea.initiate(e, "mkdir", debug);
		}
	}
	public void reboot(){
		try{
			Main main = new Main();
			File cache = new File(path + "resources" + splitter + "boot" + splitter + "systemCache.sc");
			if(cache.delete()){}else{print("WARNING [DreamOS_Core]: Cache delete was unsuccessful.");}
			main.reboot();
		}catch(Exception e){
			ea.initiate(e, "reboot", debug);
		}
	}	
	public void fastHelp(){
		try{
			if(root==true){
				print("WARNING! This firmware is unlocked. The security is disabled.");
			}
			print("cd");
			print("chpref");
			print("delete");
			print("fasthelp");
			print("fs");
			print("help");
			print("list");
			print("mkdir");
			print("rdpref");
			print("read");
			print("reboot");
			print("runcommand");
			print("shutdown");
			print("write");
			if(debug==true){
				print("[DEBUG] var");
				print("[DEBUG] var.edit");
			}
		}catch(Exception e){
			ea.initiate(e, "fasthelp", debug);
		}
	}
	public void list(){
		try{
			File file = new File(currentDir);
			File[] list = file.listFiles();
			String[] fileList = new String[list.length];
			for(int a=0; a<list.length; a++){
				if(list[a].isDirectory()){
					fileList[a] = "[DIR] " + list[a].getName();
				}else{
					fileList[a] = "[FILE] " + list[a].getName();
				}
				print(fileList[a]);
			}
		}catch(Exception e){
			ea.initiate(e, "list", debug);
		}
	}
	public void endOS(){
		print("Shutting down OS!");
		try{
			File cache = new File(path + "resources" + splitter + "boot" + splitter + "systemCache.sc");
			if(cache.delete()){}else{print("WARNING [DreamOS_Core]: Cache delete was unsuccessful.");}
			System.exit(0);
		}catch(Exception e){
			ea.initiate(e, "endOS", debug);
			print("Entering safemode...");
			delta.safeOS();
		}
	}
	public static void print(String s){
		System.out.println(s);
	}
}