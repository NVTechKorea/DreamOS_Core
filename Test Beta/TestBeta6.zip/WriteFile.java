// Declaration:
// WriteFile version: Test Beta 6
// Package Build: 18B072967UD-TB6
// Copyright (C) Dream Project Group
import java.util.Random;import java.io.*;
public class WriteFile{
	public WriteFile(){}
	public void initiate(String path, String contents){
		String process = "Writing file: " + path;
		Writer writer = null;
		try{
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path), "utf-8"));
			writer.write(contents);
		}catch(Exception e){
			System.out.println("ERROR [WRITER]");
			ErrorAnalyzer ea = new ErrorAnalyzer();
			ea.initiate(e, process, false);
		}finally {
			try {
				writer.close();
			} catch (Exception ex) {
				System.out.println("ERROR");
			}
		}
	}
}