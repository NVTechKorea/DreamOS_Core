// Declaration:
// MakeDir version: Test Beta 6
// Package Build: 18B072967UD-TB6
// Copyright (C) Dream Project Group
import java.io.*;
public class MakeDir{
	public MakeDir(){}
	public void initiate(String path){
		String process = "Making directory: " + path;
		File file = null;
		try{
			file = new File(path);
			file.mkdir();
		}catch(Exception e){
			System.out.println("ERROR [MAKEDIR]");
			ErrorAnalyzer ea = new ErrorAnalyzer();
			ea.initiate(e, process, false);
		}
	}
}