// Declaration:
// Core version: Boot Engine Test Beta 1
// Copyright (C) Dream Project Group
import java.util.Random;
import java.util.*;
import java.io.*;
public class Core{
	String path = null;
	boolean secureOption = false;
	String version = null;
	boolean debug = false;
	String splitter = null;	
	ErrorAnalyzer ea = null;
	boolean root = false;
	public Core(String tempPath, boolean tempSecureOption, String tempVersion, boolean tempDebug, boolean temproot){
		//Copy variables in here
		ea = new ErrorAnalyzer();
		path = tempPath;
		secureOption = tempSecureOption;
		version = tempVersion;
		debug = tempDebug;
		OSReader getSplitter = new OSReader();
		String[] temp1 = getSplitter.initiate();
		splitter = temp1[0];
		root = temproot;
	}
	public void initiate(){
		print("INFO [CORE]: Boot complete: " + version);
		if(root){
			secureOption = true;
		}
		if(!secureOption){
			Shield shield = new Shield(path, secureOption);
			home();
		}else{
			if(root){
				secureOption = false;
			}
			home();
		}
	}
	public void home(){
		print("Type fasthelp to see available commands.");
		try{
			Scanner input = new Scanner (System.in);
			String in = null;
			for(;;){
				in = input.nextLine();
				if(in.equals("shutdown")){
					endOS();
				}else if (in.equals("fasthelp")) {
					fastHelp();
				}
			}
		}catch(Exception e){
			ea.initiate(e, "Core");
		}
	}
	public void fastHelp(){
		if(root==true){
			print("WARNING! This firmware is unlocked. The security is disabled.");
		}
	}
	public void endOS(){
		print("Shutting down OS!");
		try{
			File cache = new File(path + "resources" + splitter + "boot" + splitter + "systemCache.sc");
			if(cache.delete()){}else{print("WARNING [CORE]: Cache delete was unsuccessful.");}
			System.exit(0);
		}catch(Exception e){
			ea.initiate(e, "endOS");
			System.exit(0);
		}
	}
	public static void print(String s){
		System.out.println(s);
	}
}