// Declaration:
// ReadFile version: Boot Engine Test Beta 1
// Copyright (C) Dream Project Group
import java.util.Random;
import java.io.*;
public class ReadFile{
	public ReadFile(){}
	public String initiate(String path){
		String data = null;
		String process = "Reading file: " + path;
		try{
			BufferedReader breader = null;
			breader = new BufferedReader(new FileReader(path));
			data = breader.readLine();
		}catch(Exception e){
			System.out.println("ERROR [READER]");
			ErrorAnalyzer ea = new ErrorAnalyzer();
			ea.initiate(e, process);
		}
		return data;
	}
}