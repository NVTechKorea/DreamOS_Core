// Declaration:
// Parser version: Boot Engine Test Beta 2
// Copyright (C) Dream Project Group
import java.util.Random;
import java.security.MessageDigest;
public class Parser{
	String memory=null;
	String debugOption=null;
	String verbose=null;
	String secureOption=null;
	String customBootHashSet=null;
	String ver = null;
	String bootPath = null;
	public Parser(){}
	public void parseMainParam(String raw_parameter, String version, String booterPath){
		ver = version;
		bootPath = booterPath;
		String[] parsed_parameter = raw_parameter.split(" -");
		String temp_debugOption = parsed_parameter[1];
		String temp_verbose = parsed_parameter[2];
		String temp_secureOption = parsed_parameter[3];
		String temp_customBootHashSet = parsed_parameter[4];
		String[] parse_debugOption = temp_debugOption.split(" ");
		String[] parse_verbose = temp_verbose.split(" ");
		String[] parse_secureOption = temp_secureOption.split(" ");
		String[] parse_customBootHashSet = temp_customBootHashSet.split(" ");
		parse2(parse_debugOption[1], parse_verbose[1], parse_secureOption[1], parse_customBootHashSet[1]);
	}
	public void parse2(String debugOption0, String verbose0, String secureOption0, String customBootHashSet0){
		debugOption=debugOption0;
		verbose=verbose0;
		secureOption=secureOption0;
		customBootHashSet=customBootHashSet0;
		boolean verboseConverted = false;
		boolean debugOptionConverted = false;
		boolean secureOptionConverted = false;
		if(verbose.equals("true")){
			verboseConverted = true;
		}else if (verbose.equals("false")) {
			verboseConverted = false;
		}else{
			parseError("Unknown verbose option.");
			print("Replacing to default: false");
			verboseConverted = false;
		}
		if(debugOption.equals("true")){
			debugOptionConverted = true;
		}else if (debugOption.equals("false")) {
			debugOptionConverted = false;
		}else{
			parseError("Unknown debug option.");
			print("Replacing to default: false");
			debugOptionConverted = false;
		}
		if(secureOption.equals("true")){
			secureOptionConverted = true;
		}else if (secureOption.equals("false")) {
			secureOptionConverted = false;
		}else{
			parseError("Unknown secure boot option.");
			print("Replacing to default: true");
			secureOptionConverted = true;
		}
		bootprint("Bootloader bootstrapper initiated.");
		boolean pass = false;
		Random rand = new Random();
		int hashTargetInt = rand.nextInt(11152346) + 1;
		String hashTarget = "<START>" + hashTargetInt + "<END>";
		String generatedHash = encryptionEngine(hashTarget);
		if(!customBootHashSet.equals("null")){
			if(customBootHashSet.startsWith("<START>null<UNLOCKHASH>52784424A094458E4DC18E4C6E2E552B2B35ED892C2CF412787731B16939F920<END><END>")){
				bootprint("Firmware is now open.");
				secureOptionConverted = false;
				Boot boot = new Boot(verboseConverted, secureOptionConverted, debugOptionConverted, bootPath, generatedHash, ver, "true");
				boot.initiate();
			}else{
				booterror("Security error. Signed key is broken.(E:47)");
				System.exit(0);
			}
			bootprint("Custom boot hash is enabled.");
			String gottenHash = encryptionEngine(customBootHashSet);
			print("Requested boot hash: " + gottenHash);
			for(;;){
				hashTargetInt = rand.nextInt(11152346) + 1;
				hashTarget = "<START>" + hashTargetInt + "<END>";
				generatedHash = encryptionEngine(hashTarget);
				if(generatedHash.equals(gottenHash)){
					System.out.println("INFO [BOOT]: Boot successful with: " + generatedHash);
					pass=true;
					Boot boot = new Boot(verboseConverted, secureOptionConverted, debugOptionConverted, bootPath, generatedHash, ver, "false");
					boot.initiate();
				}else{
					try{
						System.out.println("ERROR [BOOT]: Generated hash does not match: " + generatedHash);
						Thread.sleep(1000);
					}catch(Exception e){}
				}
			}
		}else{
			//LAUNCH FROM HERE
			bootprint("Default boot hash is enabled.");
			for(;;){
				hashTarget = "<START>" + hashTargetInt + "<END>";
				generatedHash = encryptionEngine(hashTarget);
				String gottenHash = encryptionEngine(hashTarget);
				if(generatedHash.equals(gottenHash)){
					System.out.println("INFO [BOOT]: Boot successful with: " + generatedHash);
					pass=true;
					Boot boot = new Boot(verboseConverted, secureOptionConverted, debugOptionConverted, bootPath, generatedHash, ver, "false");
					boot.initiate();
				}else{
					try{
						System.out.println("ERROR [BOOT]: Generated hash does not match: " + generatedHash);
						Thread.sleep(1000);
					}catch(Exception e){}
				}
			}
		}
	}
	public String encryptionEngine(String key) {
		String res = null;
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hash = digest.digest(key.getBytes("UTF-8"));
			StringBuffer hexString = new StringBuffer();
			for (int i = 0; i < hash.length; i++) {
				String hex = Integer.toHexString(0xff & hash[i]);
				if (hex.length() == 1)
					hexString.append('0');
				hexString.append(hex);
			}

			res = (hexString.toString());

		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		return res;
	}
	public static void print(String s){
		System.out.println("INFO [Parser]: " + s);
	}
	public static void parseError(String s){
		System.out.println("ERROR [Parser]: " + s);
	}
	public static void booterror(String s){
		System.out.println("ERROR [BOOT]: " + s);
	}
	public static void bootprint(String s){
		System.out.println("INFO [BOOT]: " + s);
	}
}